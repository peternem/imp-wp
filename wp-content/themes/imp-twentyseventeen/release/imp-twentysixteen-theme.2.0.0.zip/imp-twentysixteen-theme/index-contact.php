
<section id="contact" class="parallax-window">
    <div class="parallax-static-content">
        <div class="col-lg-8 align-center hide-sm">
            <h1 class="entry-title">Contact</h1>
            <p class="lead">Feel free to contact me about freelance web projects and or full-time work via email.</p>
        </div>
        <div class="col-lg-2">
            <div class="see-more-link">
                <a class="btn btn-primary" role="button" title="Contact" id="scEvent" href="/contact">Contact Me! <i class="fa fa-angle-double-right"></i></a>
            </div>
        </div>
    </div>
    <div id="js-parallax-background" class="parallax-background"></div>
</div>


