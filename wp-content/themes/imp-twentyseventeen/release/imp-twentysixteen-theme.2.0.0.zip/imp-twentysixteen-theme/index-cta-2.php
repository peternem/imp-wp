<div id="singlePostHero" class="outer-container parallax-container white opacity" data-natural-height="700" data-natural-width="2500" data-image-src="/wp-content/uploads/2015/05/mp-slider-image-5-2500x700.jpg" data-speed="0.2" data-bleed="10" data-parallax="scroll" style="height: 50vh; width: inherit;">
    <div class="inner-container">
        <header class="entry-header">
            <h1 style="text-align: center;" data-fontsize="43" data-lineheight="62">A Foggy Early Morning on the Hoh River</h1>
            <hr>
            <h3 style="text-align: center;" data-fontsize="23" data-lineheight="32">Lorem ipsum dolor sit amet, consectetur adipiscing elit.</h3>
        </header>
    </div>
</div>