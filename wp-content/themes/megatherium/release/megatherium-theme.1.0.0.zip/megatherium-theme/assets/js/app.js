/*!  - v1.0.0 - 2017-05-08
 * https://github.com/peternem/imp-wp#readme
 * Copyright (c) 2017; * Licensed GPLv2+ */
